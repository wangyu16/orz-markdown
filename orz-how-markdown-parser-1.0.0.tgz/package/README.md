# @orz-how/markdown-parser

A deeply customized markdown-it parser configured with several official plugins and many custom plugins designed to render interactive objects, embedded rich media, and invisible data.

## Install

```sh
npm install @orz-how/markdown-parser
```

## Quick Start

Import the configured markdown instance:

```js
import md from '@orz-how/markdown-parser';

const html = md.render('# Your Markdown Here');
console.log(html);
```

## Themes

We provide multiple ready-to-use CSS themes for rendering the output! 

Themes can be easily imported from the `themes` directory:
```js
import '@orz-how/markdown-parser/themes/light-academic-1.css';
```
Please read `themes/README.md` for a full list of components.

## Environment Requirement

Designed for standard ESM environments Node 20+.
